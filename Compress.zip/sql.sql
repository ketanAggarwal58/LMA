INSERT INTO User(firstName, lastName, phoneNo, email, dob, password) VALUES();
SELECT * FROM User WHERE email = ?